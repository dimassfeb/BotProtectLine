BotProtect

Menggunakan script LineVodka dari MerKremont dan dicampur script LIN3-TCR dari alfathdirk

Cara install sama seperti BotKick / Line Vodka / LIN3-TCR
 

Fungsi :
Saat ada yang mencoba mengusir 1 member dari grup, bot otomatis akan mengusir Kicker tersebut dari grup
